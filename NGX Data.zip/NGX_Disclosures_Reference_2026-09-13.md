# NGX Corporate Disclosures — Reference Document

**Data obtained: September 13, 2026.** Source: NGX's public corporate disclosures page (ngxgroup.com/exchange/data/corporate-disclosures/), read via Claude in Chrome, no login required.

**Coverage window: June 15 – September 13, 2026 (90 days).**

**⚠ CUTOFF RULE FOR FUTURE PULLS: any future disclosure review should cover filings dated *after September 13, 2026 only*. Do not re-request the June 15–Sept 13 window — it is fully captured below.**

**Tickers covered (44):** MTNN, ZENITHBANK, ARADEL, UACN, GTCO, NEM, UNILEVER, ETERNA, MAYBAKER, CWG, MBENEFIT, BUACEMENT, BETAGLAS, SEPLAT, LEARNAFRCA, STANBIC, FIDSON, TRANSCORP, ACCESSCORP, PZ, UCAP, UBA, UPDCREIT, FIRSTHOLDCO, AIICO, TIP, NGXGROUP, CUTIX, WAPIC, OANDO, ROYALEX, INTBREW, CHAMS, NAHCO, TANTALIZER, NPFMCRFBK, CUSTODIAN, DANGSUGAR, PRESCO, OKOMUOIL, BUAFOODS, DANGCEM, ETI, CONHALLPLC

---

## PART 1 — Material findings requiring action (read this section first)

| Ticker | Finding | Date | Impact |
|---|---|---|---|
| **PRESCO** | Court of Appeal reversed the Federal High Court ruling against Presco "in its entirety" — 2025 AGM, resolutions, and rights issue all confirmed valid | Aug 21, 2026 | The litigation that justified a SELL call is resolved. Re-verify live bid depth — market may not have repriced yet |
| **FIRSTHOLDCO** | Calvados Global Services (Femi Otedola-related) bought ~2.87 billion shares across 5 filings over 5 weeks, price rising ₦109.88→₦140.00 | Jul 22–Aug 24, 2026 | Sustained, large, convicted insider accumulation |
| **STANBIC / ACCESSCORP / UBA** | All three separately disclosed delays filing H1 2026 audited financials, citing audit finalization + pending CBN approval | Aug 10 / Aug 17 / Aug 24, 2026 | Sector-wide pattern across 3 major banks in one quarter — cause unconfirmed |
| **BETAGLAS** | Mandatory takeover offer (Emerald HoldCo/Helios, ₦590.94/share) **has closed** | Offer period Jul 7–Aug 4, 2026 | No longer "pending" — check resulting float/governance impact |
| **SEPLAT** | Sold 10% NNPC-SEPNU JV interest for ~$281.6M; ~$140M of proceeds earmarked for a special dividend | Announced Jul 30, 2026 | Real capital-return catalyst behind the technical breakout |
| **MBENEFIT** | PBT declined 16% YoY (₦10.35bn vs ₦12.29bn) despite revenue +3%; a NED sold 1.5M units | Filing Jul 30 / dealing Jun 16, 2026 | Downgrades the "clean growth" thesis — margin pressure is real |
| **LEARNAFRCA** | NED sold 305,392 shares (~₦2.7M) | Aug 10–13, 2026 | Downgrades a name previously treated as an uncomplicated new pick |
| **CUSTODIAN** | MD bought 19.5M units (~₦1.3bn), CFO also bought; PAT +39% (H1), +57% (FY2026F) | Jun 26 & 29, 2026 (filed Jul 1–2) | Upgrades this out of the low-conviction tier |
| **DANGSUGAR** | H1 2026 PBT ₦44.09bn vs an actual **loss** of ₦22.11bn in H1 2025 | Filing Jul 30, 2026 | Real turnaround, not just "cheap" |
| **UCAP** | 40 insider filings, almost entirely a company-wide staff share purchase; Board Chairman personally bought 1.33M units | Jun 4–Aug 19, 2026 | Broad organizational conviction, stronger than one individual buying |
| **CUTIX** | External auditor resigned ("strategic review of portfolio") same period as a swing from FY profit to FY loss | Resignation Aug 28; FY loss filed Jul 29, 2026 | Timing worth not dismissing even if individually explainable |
| **ROYALEX** | Filed an earnings forecast the same day as actual results — forecast ~7x higher than actual (₦462M vs ₦67-99M PBT) | Both Jul 27, 2026 | Real guidance-credibility problem |
| **OANDO** | Q1 2026 PAT declined 67% YoY despite an "improving trend" narrative in the same release; pursuing a ₦200bn rights issue | Filed Jul 2026 | Real dilution risk ahead; headline narrative undersells a bad quarter |
| **TRANSCORP** | Revenue declined 13.4% YoY — "reduced energy output and lower hospitality revenue" | Filed Jul 22, 2026 | Real fundamental softening, not just a technical read |
| **ETI** | Dollar-basis profit grew (+6%), but naira-denominated PAT fell 6% on FX | Filed Jul 28, 2026 | The NGN-relevant number is down, not up |

---

## PART 2 — Full ticker-by-ticker disclosure log

### MTNN — MTN Nigeria Communications Plc
- Aug 28: Exit of Mrs. Eyitope Kola-Oyeneyin from the Board (routine)
- Jul 30: Board Meeting Resolution (routine)
- Jul 1: Agusto & Co upgrades rating to AAA (routine)
- Jun 22: Notification on Vesting of Shares on Employees (routine)
- Jun 16: Notice of Board Meeting (routine)
- **Jul 30 — H1 2026 Financial Statement**: Revenue ₦2,993,064m vs ₦2,377,752m (+25.9%). PBT ₦1,091,586m vs ₦622,262m (+75.4%). PAT ₦707,541m vs ₦414,856m (+70.6%).
- **Jul 30 — Interim Dividend No. 36**: ₦26/share, qualification Aug 20, payment Sept 7, 2026.
- **DirectorsDealings (9 filings, Jun16–28)**: Net insider buying. CFO Modupe Kadri bought twice (1,313,732 @ avg ₦782.39; 275,309 @ ₦793). Employee Share Acquisition Trust bought 10,936,271 (avg ₦796.76) + 1,233,299 (avg ₦747.42). Two small junior-staff sells (4,950 @ ₦820; 2,370 @ ₦867), immaterial.

### ZENITHBANK — Zenith Bank Plc
- Aug 19, Jul 30: Announcements (routine, unreadable detail)
- Jun 30: Notice of Board Meeting (routine)
- **DirectorsDealings (8 filings, Jun15–29)**: Executive Director Kennedy Onuwa bought 5 separate times into a *declining* price (₦124.00→₦113.75) — conviction buying on weakness. One sell was a staff provident fund (70,000 units @ ₦114.90), not a comparable signal.
- *Note: several dealing PDFs are scanned images — figures read visually, not machine-extracted.*

### ARADEL — Aradel Holdings Plc
- Jul 31 (x2), Jul 28, Jul 1, Jun 19, Jun 17: routine board/AGM notices
- **Jul 30/31 — Q2 2026**: Revenue ₦2,491,454,085k vs ₦368,076,934k (+577%, acquisition-driven). PBT ₦752,710,999k. PAT ₦191,044,906k vs ₦146,393,838k.
- **Jun 22 — Q1 2026**: Revenue ₦728,519,315k vs ₦199,867,407k. PBT ₦283,837,813k vs ₦67,174,163k. PAT ₦120,291,605k vs ₦34,196,585k.
- **Jun 22 — Final dividend**: ₦23.00/share FY2025, paid Jul 30.
- **DirectorsDealings (12 filings, all filed Jul 3, transactions late June)**: **Company Secretary/Group General Counsel Titilola Omisore sold 5,000,000 units @ ₦1,275. GM Refinery Temitayo Ogunbanjo sold 3,530,061 units @ ₦1,282.50.** Against this, ~10 small junior/graduate buys (111–38,080 units each) — immaterial individually.

### UACN — UAC of Nigeria Plc
- Jul 14, Jun 25: routine
- **Jul 29 — Q2 2026**: Revenue ₦364,970,145k vs ₦110,405,688k (+230%, CHI Ltd acquisition). PBT ₦34,445,459k. PAT ₦20,025,903k.
- **DirectorsDealings (2)**: Dalio Property Development (related to NED Khalifa Biobaku) sold 45,197,311 shares @ ₦185. Employee Ayomipo Wey sold 2,469,604 @ ₦185.

### GTCO — Guaranty Trust Holding Company Plc
- Sept 1, Aug 4, Jul 1: Total Voting Rights reports (routine)
- Aug 20: Publication of Interim Results (routine)
- Jun 26: Notice of Board Meeting
- No DirectorsDealings, no unusual titles.

### NEM — NEM Insurance Plc
- Jul 29: Board Meeting Resolution (routine)
- Aug 6: NED Mrs. Joy Teluwo's tenure expired Jul 29, stepped down (routine)
- **Jul 28 — Q2 2026**: Insurance revenue ₦71,201,344k vs ₦75,410,983k (down slightly). PBT ₦20,958,610k vs ₦17,937,512k. PAT ₦18,087,281k vs ~₦15,480,072k.
- Sept 9 & Jun 11 EarningForecast filings: scanned, not extracted.

### UNILEVER — Unilever Nigeria Plc
- Jun 29 (x2): Board meeting notice; Ibrahim Sodipe resigned as ED, replaced by Modupe Femi-Okunbanjo
- **Jul 21 — Q2 2026**: Revenue ₦119,923,255k vs ₦98,102,214k. PBT ₦29,175,787k. PAT ₦15,597,838k vs ₦14,405,316k.
- **Jul 21 — Interim dividend**: ₦2.00/share, payment Aug 14.
- No DirectorsDealings.

### ETERNA — Eterna Plc
- Aug 13, Jul 21, Jul 9, Jun 2: routine
- **Jul 30 — Q2 2026**: Revenue ₦217,313,027k vs ₦157,654,869k (+38%). PBT ₦7,665,473k vs ₦1,568,427k. PAT ₦5,884,820k vs ₦573,814k.
- **DirectorsDealings (Aug 11)**: NED Emmanuel Omuojine bought 8,154 units @ ₦33.00.
- Sept 10 & Jun 10 EarningForecast: scanned, not extracted.

### MAYBAKER — May & Baker Nigeria Plc
- Jul 29, Jul 16, Jun 8: routine
- **Aug 18 — Public Notice of Fraudulent Investment Scheme**: Company disowning a fake "M&B Equity Stake" scheme using its name — company is the party protecting the public, not implicated in anything.
- **Jul 29 — Q2 2026**: Revenue ₦19,280,367k vs ₦19,283,531k (flat). PBT ₦4,848,300k vs ₦3,214,129k (+50.8%). PAT ₦3,199,878k vs ₦2,185,608k (+46.4%).

### CWG — CWG Plc
- **Jul 30 — Q2 2026**: Revenue ₦44,396,801k vs ₦36,764,611k (+21%). PBT ₦4,796,898k. PAT ₦3,645,643k vs ₦3,559,383k.
- No other filings in window.

### MBENEFIT — Mutual Benefits Assurance Plc
- Aug 6, Jul 3: routine
- **Jul 30 — Q2 2026**: Insurance revenue ₦42,253,300k vs ₦41,195,472k (+3%). **PBT ₦10,352,199k vs ₦12,285,319k (-16%).** PAT ₦9,752,950k vs ₦11,593,757k.
- Jun 19 — EarningForecast (9M-2026): Insurance revenue ₦58.5bn, PBT ₦16,028,096k, PAT ₦14,123,603k (no comparative).
- Jun 1 — Final dividend 4 kobo/share, paid Jul 30.
- **DirectorsDealings (Jun 16)**: NED Dr Akinade Ogunbiyi **sold** 1,507,309 units @ ₦4.20–4.33.

### BUACEMENT — BUA Cement Plc
- Jul 16, Jul 2 (x2): routine
- **Jul 23 — Q2 2026**: Revenue ₦728,925,338k vs ₦580,303,927k (+25.6%). PBT ₦384,437,583k. PAT ₦324,878,478k vs ₦180,895,223k.
- **DirectorsDealings (4, Jun4–26)**: Two pairs of relatives of MD/Board Member trading identical volumes at identical prices with each other (63,572 units @ ₦340.20; 115,585 units @ ₦378.00) — reads as intra-family transfer, not a market signal.

### MAYBAKER — see above (combined; do not duplicate)

### BETAGLAS — Beta Glass Plc
- Aug 5, Jun 26 (x2): routine
- **Jul 31 — Q2 2026**: Revenue ₦79,714,683k vs ₦78,232,907k (+1.9%). **PBT ₦24,481,252k vs ₦27,604,431k (-11.3%). PAT ₦16,157,627k vs ₦18,705,346k (-13.6%).**
- **Jul 7 — Mandatory Takeover Offer**: Emerald HoldCo B.V. (Helios-controlled), up to 11,741,509 shares @ ₦590.94, offer period **Jul 7–Aug 4, 2026 (now closed)**, following Emerald's acquisition of 55.21% via Packaging Industries Nigeria Ltd + Emerald Nigeria Intermediate Holdings.
- No DirectorsDealings.

### SEPLAT — Seplat Energy Plc
- Aug 24 (x2), Aug 13, Jul 30 (x3), Jul 16, Jun 24, Jun 9, Jun 5: routine board/admin/FX notices
- **Jul 30 — Q2 2026**: Revenue $1,820.0m vs $1,397.7m (+30%). PBT $574.9m vs $292.9m. PAT $164.0m vs $27.4m (+498%).
- **DirectorsDealings (Jun 10)**: INED Christopher Okeke bought 59,994 shares @ £5.732191.
- **Jul 30 — Sale of 10% NNPC-SEPNU interest** for ~$281.6m; ~half to debt reduction, ~$140m to a special dividend; NNPC's stake rises to 70%; completion H2 2026.

### LEARNAFRCA — Learn Africa Plc
- Sept 8, Aug 14, Jul 1: routine
- **DirectorsDealings (Aug 18)**: NED Hajia Binta Bakari **sold** 305,392 shares, avg ₦8.95.
- **Jul 30 — Q1 FY2027 (3M to Jun 30)**: Revenue ₦1,246,695,000 vs ₦295,475,000. PBT loss ₦124,341,000 vs prior loss ₦354,872,000 (improved but still loss-making).
- **Jun 30 — FY audited (year to Mar 31, 2026)**: Revenue ₦6,154,379,000 vs ₦5,182,891,000 (+19%). PBT ₦1,188,842,000 vs ₦748,212,000 (+59%). PAT ₦753,109,000 vs ₦474,978,000 (+59%).
- Sept 10 & Jun 11 EarningForecast: scanned, not extracted.

### STANBIC — Stanbic IBTC Holdings Plc
- **Aug 10 — Notice of potential delay filing H1 2026 audited FS**, citing audit finalization + regulatory approval, targeting the Aug 28 deadline.
- **Jun 10 — Disclaimer Notice**: warning public of fraudulent ads using Stanbic's name/logos promising "guaranteed returns" — company is the protecting party.
- No DirectorsDealings in window (one on record, May 29, falls outside).

### FIDSON — Fidson Healthcare Plc
- **Jul 24 — Q2 2026**: Revenue ₦74,484,661k vs ₦62,644,162k (+18.8%). PBT ₦11,699,397k (+30.1%). PAT ₦7,721,602k (+28.9%).
- **Jul 22 — Final dividend**: ₦1.50/share, paid Jul 31.
- No DirectorsDealings.

### TRANSCORP — Transnational Corporation Plc
- Jun 30: routine
- **Jul 22 — Q2 2026**: **Revenue ₦241,529,759k vs ₦279,037,465k (-13.4%)**, driven by reduced energy output and lower hospitality revenue. PBT ₦75,884,199k vs ₦85,696,844k. PAT ₦54,366,769k vs ₦65,171,739k.
- **Jul 22 — Interim dividend**: 40 kobo/share.
- **DirectorsDealings (5, all filed Jul 29, transactions Jul 27-28)**: Broad, genuine executive buying including **President/Group CEO Owen Omogiafo bought 1,900,800 units** (avg ₦39.89), plus CFO, Group Company Secretary, and two department heads all buying. Real, coordinated conviction buying despite the weak revenue print.

### ACCESSCORP — Access Holdings Plc
- Aug 28, Aug 1, Jul 31, Jul 10, Jul 2, Jun 25, Jun 15, Jun 11, Jun 4 (x2): routine
- **Jul 31 — Response to False Social Media Publication**: denied a false claim that "Access Bank Plc will cease banking operations"; reported to regulators/law enforcement.
- **Aug 17 — Potential delay in Interim Audited FS**, pending audit finalization + CBN approval.
- **DirectorsDealings (3, filed Jul 1)**: NED Olusegun Ogbonnewo bought 6,700,000 shares @ ₦23.00. Two staff sells (1.6M @ ₦23.00; 2.5M @ ₦24.25).

### PZ — PZ Cussons Nigeria Plc
- Sept 9, Aug 31: routine. No Financial Statement, DirectorsDealings, or unusual titles in window.

### UCAP — United Capital Plc
- **Jul 27 — Q2 2026**: Revenue ₦37,492,271k vs ₦23,761,422k (+58%). PBT ₦24,776,866k (+80%). PAT ₦21,096,797k.
- **Jul 27 — Interim dividend**: ₦0.30/share.
- **DirectorsDealings (40 filings, Jun4–Aug19)**: Overwhelmingly a company-wide staff share-purchase program across every level of the organization, including **Board Chairman Ike Uche buying 1,332,000 units** (avg ₦18.18, Jun 23). One small staff sell (3,651 units @ ₦17.85, Aug 18).

### UBA — United Bank for Africa Plc
- Jul 1: routine
- **Aug 24 — Potential delay in H1 2026 audited FS publication**: Board approved Aug 13, awaiting NGX/CBN approval, deadline extended to Sept 30.
- **Aug 20 — Approval of Audited H1 2026 FS**: approved Aug 13 (pending CBN); appointed Ibrahim Ajimasu Puri as NED.
- **DirectorsDealings**: Vine Foods Limited (related to NED Emmanuel Nnorom) bought 85,278 shares @ ₦44.60.
- No standalone Q2 Financial Statement filed under that label — only the delay/approval notices above.

### UPDCREIT — UPDC Real Estate Investment Trust
- **Jul 29 — Q2 2026**: Revenue ₦2,197,064k vs ₦1,536,814k. Net increase in net assets ₦1,719,257k vs ₦1,098,813k.
- Aug 10 — REIT distribution payment: scanned, not extracted.
- No DirectorsDealings.

### FIRSTHOLDCO — First HoldCo Plc
- Jul 20, Jul 1, Jun 9, Jun 1: routine
- **Jul 20 — Q2 2026**: Revenue ₦1,932,837m vs ₦1,656,829m. PBT ₦653,536m. PAT ₦526,130m vs ₦289,772m.
- **Jul 30 — Dividend policy**: minimum 60% of Group PAT to be distributed annually going forward.
- **DirectorsDealings (7, Jun16–Aug24)**: **Calvados Global Services (Femi Otedola-related) bought across 5 filings, ~2.87 billion shares total, Jul 22–Aug 24, price rising ₦109.88→₦140.00.** NED Anil Dua also bought twice (1.3M @ ₦58.70; 2.1M @ ₦65.40).

### AIICO — AIICO Insurance Plc
- Jun 25: routine
- **Jul 31 — Q2 2026**: Insurance revenue ₦74,930,909k vs ₦65,425,099k (+15%). PBT ₦15,054,351k (+21%). PAT ₦13,404,162k (+19%).
- Sept 10 EarningForecast (FY2026): Insurance revenue ₦156,335,732k, PBT ₦25,048,259k, PAT ₦22,412,948k (no comparative).
- No DirectorsDealings.

### TIP — The Initiates Plc
- Jul 21: routine
- **Jul 30 — Q2 2026**: Revenue ₦6,951.06m vs ₦3,388.39m (+105%). PBT ₦2,990.87m (+120%). PAT ₦1,753.53m (+89%) — growth from waste management and industrial cleaning services.
- **Jul 31 — Interim dividend**: ₦0.20/share.
- No DirectorsDealings.

### NGXGROUP — Nigerian Exchange Group Plc
- **Jul 27 — H1 2026**: Revenue ₦17.60bn vs ₦8.08bn (+118%). PBT ₦14.76bn (+170%). PAT ₦10.36bn vs ₦4.22bn.
- No other filings.

### CUTIX — Cutix Plc
- Aug 28 (x2), Aug 6, Jul 30, Jul 21, Jul 14, Jul 7, Jun 26: routine
- **Sept 2 — External auditor resignation**: Ngozi Monica Okonkwo & Co. resigned effective Aug 28, "strategic review of audit portfolio"; replacement pending regulatory approval.
- **DirectorsDealings (Sept 11)**: INED Olayinka Abayomi Abimbola bought 60,000 units @ ₦2.45.
- **Aug 28/29 — Q1 FY2027 (3M to Jul 31)**: Revenue ₦3,704,762k vs ₦3,523,741k (+5%). PBT ₦88,355k vs prior loss ₦(89,415)k (return to profit).
- **Jul 29 — FY (year to Apr 30, 2026)**: Revenue ₦14,771,484k vs ₦15,773,070k (-6%). **PBT loss ₦(124,764)k vs prior profit ₦1,609,507k. PAT loss ₦(198,021)k vs prior profit ₦1,031,830k** — swing from profit to loss.

### WAPIC — Coronation Insurance Plc (rebranded from Wapic)
- Sept 1, Jul 6: routine
- Jul 30 — Q2 2026: **filing located but P&L figures not extracted** (long document, extraction tool couldn't reach later pages). **NEEDS MANUAL FOLLOW-UP.**
- No DirectorsDealings.

### OANDO — Oando Plc
- Jun, Jul, Aug: routine press releases and AGM notice
- **Q2 2026 (H1)**: Revenue ₦2,063,509,425k vs ₦1,720,796,250k (+20%). PBT loss ₦(32,839,668)k vs prior loss ₦(145,741,793)k (narrowed). PAT ₦68,556,136k vs ₦63,312,823k (+8%).
- **Q1 2026**: Revenue ₦989,543,676k vs ₦932,573,600k (+6%). PBT loss ₦(77,372,024)k vs prior loss ₦(52,562,178)k (**widened**). **PAT ₦37,455,156k vs ₦113,057,583k (-67% YoY)** despite the "improving" H1 narrative.
- **FY2025**: Revenue ₦3,180,090,462k vs ₦4,086,650,996k (-22%). PBT ₦135,759,960k vs ₦383,820,117k (-65%). PAT ₦204,808,573k vs ₦220,120,053k (+7%, propped up by a ₦69.05bn tax benefit vs ₦163.70bn tax expense prior year).
- **Aug — H1 2026 unaudited release**: production +16% to 42,789 boepd; guiding ~50,000 boepd for 2026; pursuing a **₦200bn rights issue** and a $1.5bn issuance programme.
- No DirectorsDealings identified.

### ROYALEX — Royal Exchange Plc
- Sept 2, Jun 22: routine
- **Jul 27/29 — Q2 2026**: Group Operating Income ₦407.3m vs ₦1,713.7m (-76%). PBT ₦67.4m vs ₦1,514.8m (-96%). PAT ₦67.4m vs ₦1,514.8m (-96%) — driven by lower associate-investment contribution.
- **Jul 27 — Earnings Forecast (same day as actuals above)**: PBT ₦461,796k, PAT ₦456,636k — **roughly 7x the actual results filed the same day.**
- No DirectorsDealings.

### INTBREW — International Breweries Plc
- Aug 3, Jul 31, Jul 13, Jul 9, Jul 7: routine
- **Jul 30 — Q2 2026**: Revenue ₦342,068,028k vs ₦340,990,220k (+0.3%). PBT ₦74,787,946k vs ₦61,527,171k (+22%). **PAT ₦38,313,833k vs ₦41,287,739k (-7% despite PBT growth — likely higher tax charge).**
- **Jul 9/11 — Proposed Share Capital Reduction**: eliminate ₦191,032,749,000 accumulated losses (as at FY2025) via the Share Premium Account, then return excess capital pro-rata — explicitly to restore capacity to pay future dividends. Requires shareholder/regulatory approval.
- No DirectorsDealings.

### CHAMS — Chams Holding Company Plc
- Jul 11, Jul 2, Jun 26, Jun 16: routine
- **Jul 30 — Q2 2026**: Group Revenue ₦9,788,763k vs ₦9,881,516k (-1%). PBT ₦606,755k (+15%). PAT ₦473,279k (+13%). **Q2-only: PBT ₦83,918k vs ₦348,067k (-76%); PAT ₦43,878k vs ₦270,089k (-84%)** — sharp Q2-specific decline despite H1 growth.
- **DirectorsDealings (4)**: **Creditville Nigeria Ltd (related to NED Michael Uwakwe) bought 500,000 @ ₦3.42 and sold 9,000,000 @ ₦3.18, both Sept 9** — net heavy selling. INED Dr Mohammed Santuraki sold 1,200,000 @ ₦3.96 (Jun 25). Dr Inioluwa Olaniyan (GMD's blood relative) bought 2,472,900 units (₦3.95–4.00, May 19).

### NAHCO — Nigerian Aviation Handling Company Plc
- Jun 29: routine
- **Jul 30 — Q2 2026**: Group Revenue ₦35,355,866k vs ₦32,329,639k (+9%). PBT ₦14,367,402k (+22%). PAT ₦10,846,304k (+22%).
- **DirectorsDealings (3)**: **Executive Director Saheed Lasisi sold twice** (94,634 @ ₦138.80, mid-Aug; 95,000 @ ₦135.72, Sept 1). ED Olusola Peter Obabori also sold 410,000 @ ₦173.85 (Jun 11).
- **Jul 3 — Board changes**: two NEDs retired after 8 years, two new NEDs appointed.

### TANTALIZER — Tantalizers Plc
- Jul 20, Jun 25: routine
- **Jul 31 — Q2 2026**: System Revenue ₦1,880,174,157 vs ₦2,904,459,504 (comparative is labeled full-year 2025, not matching H1 — treat with caution). PBT ₦45,110,214k. PAT ₦45,110,214k (no tax charge in period).
- No DirectorsDealings.

### NPFMCRFBK — NPF Microfinance Bank Plc
- Jul 3, Jun 16: routine
- Jul 24/27 — Q2 2026: **scanned/image PDF, no figures extracted. NEEDS MANUAL FOLLOW-UP.**
- No DirectorsDealings.

### CUSTODIAN — Custodian Investment Plc
- Jun 30: routine
- **Sept 9 — Earnings Forecast FY2026**: Gross Revenue ₦312.6bn vs ₦175.8bn (+78%). PBT ₦88.7bn (+53%). PAT ₦77.6bn (+57%).
- **Jul 29 — Q2 2026**: Gross Revenue ₦167,620,937k vs ₦124,276,848k (+35%). PBT ₦43,137,430k (+42%). PAT ₦36,667,310k (+39%).
- **Jul 31 — Interim dividend**: 25 kobo/50k share.
- **DirectorsDealings (3)**: **MD Wole Oshin bought 19,531,250 units** (avg ₦67.60, Jun 26 & 29). CFO Friday Nwachukwu also bought 30,000 units (~₦68.75 avg, Jun 26).

### DANGSUGAR — Dangote Sugar Refinery Plc
- Jul 1: routine
- Aug 14 — Result of Rights Issue: **extraction failed, only a stray page number returned. NEEDS MANUAL FOLLOW-UP.**
- **Jul 30 — Q2 2026**: Revenue ₦391.85bn vs ₦430.21bn (-9%). **PBT ₦44.09bn vs a loss of ₦(22.11bn) in H1 2025 — turnaround.** PAT ₦41.51bn vs a loss of ₦(24.27bn). (FY2025 as a whole was also a loss: Revenue ₦829.21bn, PBT ₦(72.28bn), PAT ₦(64.12bn).)
- **DirectorsDealings**: Senior parent-company staff member Isah Yusuf Aruwa bought 325,689 shares (~₦73.98 avg, Jun 22).

### PRESCO — Presco Plc
- Sept 8, Aug 26, Jul 29 (x3), Jul 2: routine
- **Jul 29 — Pending litigation update**: challenge to validity of Aug 2025 AGM, rights issue, and regulatory recognition. Federal High Court (Benin) ruled against Presco Dec 11, 2025; appealed.
- **Aug 24 — Follow-up**: **Court of Appeal ruled Aug 21, 2026, "allowing the Company's appeal in its entirety"** — fully reverses the Dec 2025 ruling. AGM/resolutions/rights issue confirmed valid.
- **Jul 29 — Q2 2026**: Group Revenue ₦198,750,419k vs ₦198,737,055k (flat). PBT ₦122,219,945k (+9%). PAT ₦82,274,485k vs ₦88,721,076k (-7%).
- No DirectorsDealings.

### OKOMUOIL — The Okomu Oil Palm Company Plc
- Jul 27, Jul 1: routine (Jul 27 confirms Board approved unaudited H1 2026 financials Jul 24 for release Jul 28)
- Sept 3 EarningForecast: scanned, not extracted.
- Jul 28 — Q2 2026: **P&L not extracted** (long document, tool returned only front-matter/shareholding pages). Two large unclassified figures seen (₦412,148,071,074 vs ₦229,664,854,740, likely market cap, not P&L). **NEEDS MANUAL FOLLOW-UP.**
- No DirectorsDealings.

### BUAFOODS — BUA Foods Plc
- Jul 29, Jul 17, Jul 2: routine
- **Jul 30 — Q2 2026**: Group Revenue ₦765,119,203k vs ₦912,514,434k (-16%, declines in Sugar/Flour/Rice). **PBT ₦314,881,416k vs ₦276,104,552k (+14%). PAT ₦292,266,502k vs ₦260,069,889k (+12%)** — real margin expansion (gross margin 47.5% vs 37.2%); Pasta segment +35% to ₦130.6bn.
- No DirectorsDealings.

### DANGCEM — Dangote Cement Plc
- Jul 29, Jul 3, Jun 30: routine
- **Jul 29 — Q2 2026**: Revenue ₦2,513,932m vs ₦2,071,598m (+21%). PBT ₦981,387m (+35%). PAT ₦638,534m (+23%).
- **Sept 2 — Capital Markets Day (London, Sept 21, 2026)**: follows shareholder approval of a secondary LSE listing.
- **DirectorsDealings (2, both filed Sept 8 for May transactions)**: small treasury-staff buys (986 units ~₦1,010.64 avg; 852 units @ ₦1,173.23).

### ETI — Ecobank Transnational Incorporated
- Jul 21, Jun 29: routine
- **Jul 28 — Q2 2026**: USD basis Revenue $1,281.3m (+15%), PBT $423.0m (+6%), PAT $296.1m (+6%). **NGN basis: Revenue +2%, PBT -6%, PAT -6%** — naira profit fell on FX despite dollar growth.
- **Aug 17 — EGM governance changes** (approved Aug 13): AGM quorum raised to 25% of paid-up capital; board size cut from 15 to 12; NED tenure limits removed (age-70 retirement retained); board meeting quorum raised to >50% of directors.
- No DirectorsDealings.

### CONHALLPLC — Consolidated Hallmark Holdings Plc
- Jul 3: routine
- **Sept 10 — Earnings Forecast FY2026**: Gross Revenue ₦48.36bn vs ₦43.13bn (+12%). PBT ₦32.90bn. PAT ₦26.71bn — growth driven mainly by a projected ₦23.65bn fair-value gain vs a ₦1.82bn loss prior year.
- **Aug 26 — Q2 2026**: Group PBT ₦27,101,865,754 vs ₦1,764,201,970. **PAT ₦25,277,760,135 vs ₦1,157,906,157 (+2,083%)** — driven by investment/fair-value gains, not core insurance revenue.
- **DirectorsDealings (3)**: **Substantial shareholder Sephine Edefe Nig Ltd bought 433,663,351 units** (avg ₦5.62, Aug 10–Sept 8). NED Eze Ben Onuora bought 40,000,000 @ ₦6.75 (Aug 19). NED Dr Tony Anonyai bought 11,680,462 units across 6 transactions (avg ₦6.45, May–Jun).

---

## PART 3 — Items needing manual follow-up (extraction failed)

These filings exist and were located, but their actual content could not be read in this pass (scanned/image PDFs, or documents too long for the extraction tool to reach the relevant page):

- **WAPIC** — Q2 2026 Financial Statement P&L
- **NPFMCRFBK** — Q2 2026 Financial Statement (entirely scanned)
- **OKOMUOIL** — Q2 2026 Financial Statement P&L
- **DANGSUGAR** — Result of Rights Issue (Aug 14, 2026)
- **NEM** — EarningForecast filings (Sept 9 & Jun 11)
- **ETERNA** — EarningForecast filings (Sept 10 & Jun 10)
- **LEARNAFRCA** — EarningForecast filings (Sept 10 & Jun 11)
- **AIICO** — Jun 10 EarningForecast (duplicate series, not separately extracted)
- **ZENITHBANK** — several DirectorsDealings forms read visually, not machine-extracted (lower confidence)

---

*End of document. Next disclosure review should query for filings dated after September 13, 2026 only.*
